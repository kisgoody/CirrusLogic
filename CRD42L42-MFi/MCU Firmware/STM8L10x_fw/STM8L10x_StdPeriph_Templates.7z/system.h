// pre-compiler definitions

#define HW_MAJOR_VER		0x00
#define HW_MINOR_VER		0x00
#define HW_REVISION			0x00

#define FW_MAJOR_VER		0x00
#define FW_MINOR_VER		0x01
#define FW_REVISION			0x00
// In Octobeer of 2015, the strlen function was causing problems
// The length of these strings is hard-coded into packet.c
// Do not change the length of these strings without changing the length
#define INFO_NAME			"CS42L42 Demo"
#define INFO_MANF			"Cirrus Logic"
#define INFO_MODEL			"CS42L42"
#define INFO_SERIAL			"00000000"
#define INFO_PREF_APP		"com.cirrus.CDB42L42-MFi"
#define INFO_EA_NAME		"com.cirrus.cs42l42-hs"

// function declarations

uint8_t next_button_state (uint8_t current_button_state);

void pin_setup (void);

void timer2_init (void);
void timer2_service (void);

void timer3_init (void);
void wait_15ms (void);

void codec_init (void);

void codec_reg_write (uint8_t reg, uint8_t value);
void codec_reg_write_mult (uint8_t reg, uint8_t length, uint8_t *payload);

uint8_t codec_reg_read (uint8_t reg);
void codec_reg_read_mult (uint8_t reg, uint8_t length, uint8_t *payload);

// global variables

extern volatile uint8_t timer2_count;
extern uint8_t pending_launch;
extern uint8_t HP_OUT_OFF;
extern uint8_t ADC_OFF;
