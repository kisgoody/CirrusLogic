#include "stm8l10x.h"
#include "system.h"
#include "i2c_master_poll.h"

// side button action function ------------------------------------------------
uint8_t next_button_state (uint8_t current_button_state)
{

	uint8_t temp_state;

	temp_state = current_button_state;				// latch current state

	// determine if state must change
	if (temp_state)									// button thought to be released (1)
	{
		// check for press
		if (GPIO_ReadInputDataBit (GPIOB, GPIO_Pin_4) == RESET)
		{
			wait_15ms ();							// delay (debounce)
			// check if button is still pressed
			if (GPIO_ReadInputDataBit (GPIOB, GPIO_Pin_4) == RESET)
			{
				temp_state = 0;						// change state to pressed (0)
				pending_launch = 1;				// flag set
			} // if (actually pressed)
		} // if (possibly pressed)
	} else {										// button thought to be pressed (0)
		// check for release
		if (GPIO_ReadInputDataBit (GPIOB, GPIO_Pin_4) != RESET)
		{
			wait_15ms ();							// delay (debounce)
			// check if button is still released
			if (GPIO_ReadInputDataBit (GPIOB, GPIO_Pin_4) != RESET)
			{
				temp_state = 1;						// change state to released (1)
			} // if (actually released)
		} // if (possibly released)
	} // if (state)

	return (temp_state);

} // --------------------------------------------------------------------------


// GPIO pin initialization function -------------------------------------------
void pin_setup (void)
{

	// PA2: APP button input  (CDB only)
	GPIO_Init (GPIOA, GPIO_Pin_2, GPIO_Mode_In_PU_No_IT);

	// PA6: spare
	GPIO_Init (GPIOA, GPIO_Pin_6, GPIO_Mode_In_PU_No_IT);

	// PB0:may be used to monitor /INT output of codec
	// PB1:may be used to monitor /WAKE output of codec	
	// PB0-1: codec GPIO
	GPIO_Init (GPIOB, (GPIO_Pin_0 | GPIO_Pin_1), GPIO_Mode_In_PU_No_IT);
	
	// PB2, PB3: test output  **DEBUG Only
	GPIO_Init (GPIOB, (GPIO_Pin_2 | GPIO_Pin_3), GPIO_Mode_Out_PP_Low_Slow);

	// PB4: side button input
	GPIO_Init (GPIOB, GPIO_Pin_4, GPIO_Mode_In_PU_No_IT);

	// PB5, PB6: red LED, amber LED outputs
	GPIO_Init (GPIOB, (GPIO_Pin_5 | GPIO_Pin_6), GPIO_Mode_Out_PP_Low_Slow);

	// PB7: codec reset output
	GPIO_Init (GPIOB, GPIO_Pin_7, GPIO_Mode_Out_PP_Low_Slow);

	// PC0, PC1: SDA, SCL
	GPIO_Init (GPIOC, (GPIO_Pin_0 | GPIO_Pin_1), GPIO_Mode_Out_OD_HiZ_Slow);

	/* NOTE: PC2, PC3 (UART RX, TX) configured in serial_init () */

	// PC4: LAM mute input
	GPIO_Init (GPIOC, GPIO_Pin_4, GPIO_Mode_In_PU_No_IT);

	// PD0: LAM programming input
	GPIO_Init (GPIOD, GPIO_Pin_0, GPIO_Mode_In_PU_No_IT);

	// PD4, PD5: playback indicator LEDs (development board only)
	GPIO_Init (GPIOD, (GPIO_Pin_4 | GPIO_Pin_5), GPIO_Mode_Out_OD_HiZ_Slow);

} // --------------------------------------------------------------------------


// timer 2 initialization function --------------------------------------------
void timer2_init (void)
{

	// enable clock to TIM2
	CLK_PeripheralClockConfig (CLK_Peripheral_TIM2, ENABLE);

	TIM2_DeInit ();									// reset TIM2 registers

	// configure TIM2 for 10 ms
	TIM2_TimeBaseInit (TIM2_Prescaler_128, TIM2_CounterMode_Up, 1250);

	TIM2_ITConfig (TIM2_IT_Update, ENABLE);			// enable interrupt

} // --------------------------------------------------------------------------


// timer 2 overflow interrupt handler -----------------------------------------
void timer2_service (void)
{

	// divide 10-ms timer into one-shot 1-sec timer
	if (timer2_count < 100) timer2_count++; else TIM2_Cmd (DISABLE);

	TIM2_ClearITPendingBit (TIM2_IT_Update);		// clear interrupt flag

} // --------------------------------------------------------------------------


// timer 3 initialization function --------------------------------------------
void timer3_init (void)
{

	// enable clock to TIM3
	CLK_PeripheralClockConfig (CLK_Peripheral_TIM3, ENABLE);

	TIM3_DeInit ();									// reset TIM3 registers

	// configure TIM3 for 15 ms
	TIM3_TimeBaseInit (TIM3_Prescaler_128, TIM3_CounterMode_Up, 1875);

	TIM3_GenerateEvent (TIM3_EventSource_Update);	// force update event
	TIM3_ClearFlag (TIM3_FLAG_Update);				// clear update flag

} // --------------------------------------------------------------------------


// 15-ms delay function -------------------------------------------------------
void wait_15ms (void)
{

	TIM3_Cmd (ENABLE);								// enable TIM3

	// wait for TIM3 to count
	while (TIM3_GetFlagStatus (TIM3_FLAG_Update) == RESET);

	TIM3_Cmd (DISABLE);								// disable TIM3

	TIM3_ClearFlag (TIM3_FLAG_Update);				// clear update flag

} // --------------------------------------------------------------------------


// codec initialization function ----------------------------------------------
void codec_init (void)
{

	uint8_t i;

	GPIO_SetBits (GPIOB, GPIO_Pin_7);				// take codec out of reset

	for (i = 0; i < 33; i++) wait_15ms ();			// wait for control port (500 ms)

	codec_reg_write (0x00, 0x10);					// set page 0x10
	codec_reg_write (0x09, 0x02);					// MCLK Control: /256 mode
	codec_reg_write (0x0A, 0xA4);					// DSR_RATE to ?
	codec_reg_write (0x00, 0x12);					// set page 0x12
	codec_reg_write (0x0C, 0x00);					//SCLK_PREDIV = 00
	codec_reg_write (0x00, 0x15);					// set page 0x15
	codec_reg_write (0x05, 0x40);					//PLL_DIV_INT = 0x40
	codec_reg_write (0x02, 0x00);					//PLL_DIV_FRAC = 0x000000
	codec_reg_write (0x03, 0x00);					//PLL_DIV_FRAC = 0x000000
	codec_reg_write (0x04, 0x00);					//PLL_DIV_FRAC = 0x000000
	codec_reg_write (0x1B, 0x03);					//PLL_MODE = 11 (bypassed)
	codec_reg_write (0x08, 0x10);					//PLL_DIVOUT = 0x10
	codec_reg_write (0x0A, 0x80);					//PLL_CAL_RATIO = 128
	codec_reg_write (0x01, 0x01);					//power up PLL
	codec_reg_write (0x00, 0x12);					// set page 0x12
	codec_reg_write (0x01, 0x01);					//MCLKint = internal PLL
	codec_reg_write (0x00, 0x11);					// set page 0x11
	codec_reg_write (0x01, 0x00);					//power up ASP, Mixer, HP, and DAC
	codec_reg_write (0x00, 0x1B);					// set page 0x1B
	codec_reg_write (0x75, 0x9F);					//Latch_To_VP = 1
	codec_reg_write (0x00, 0x11);					// set page 0x11
	codec_reg_write (0x07, 0x01);					//SCLK present
	codec_reg_write (0x00, 0x12);					// set page 0x12
	codec_reg_write (0x03, 0x1F);					//FSYNC High time LB. LRCK +Duty = 32 SCLKs
	codec_reg_write (0x04, 0x00);					//FSYNC High time UB
	codec_reg_write (0x05, 0x3F);					//FSYNC Period LB. LRCK = 64 SCLKs
	codec_reg_write (0x06, 0x00);					//FSYNC Period UB
	codec_reg_write (0x07, 0x2C);					//Enable ASP SCLK, LRCK input, SCPOL_IN (ADC and DAC) inverted
	codec_reg_write (0x08, 0x0A);					//frame starts high to low, I2S mode, 1 SCLK FSD
	codec_reg_write (0x00, 0x1F);					// set page 0x1F
	codec_reg_write (0x06, 0x02);					//Dac Control 2: Default
	codec_reg_write (0x00, 0x20);					// set page 0x20
	codec_reg_write (0x01, 0x01);					//unmute analog A and B, not -6dB mode
	codec_reg_write (0x00, 0x23);					// set page 0x23
	codec_reg_write (0x01, 0xFF);					//CHA_Vol = MUTE
	codec_reg_write (0x03, 0xFF);					//CHB_Vol = MUTE
	codec_reg_write (0x00, 0x2A);					// set page 0x2A
	codec_reg_write (0x01, 0x0C);					//Enable Ch1/2 DAI
	codec_reg_write (0x02, 0x02);					//Ch1 low 24 bit
	codec_reg_write (0x03, 0x00);					//Ch1 Bit Start UB
	codec_reg_write (0x04, 0x00);					//Ch1 Bit Start LB = 00
	codec_reg_write (0x05, 0x42);					//Ch2 high 24 bit
	codec_reg_write (0x06, 0x00);					//Ch2 Bit Start UB
	codec_reg_write (0x07, 0x00);					//Ch2 Bit Start LB = 00
	codec_reg_write (0x00, 0x26);					// set page 0x26
	codec_reg_write (0x01, 0x00);					//SRC in at don't know
	codec_reg_write (0x09, 0x00);					//SRC out at don't know
	codec_reg_write (0x00, 0x1B);					// set page 0x1B
	codec_reg_write (0x71, 0xC1);					//Toggle WAKEB_CLEAR
	codec_reg_write (0x71, 0xC0);					//Set WAKE back to normal
	codec_reg_write (0x75, 0x84);					//Set LATCH_TO_VP
	codec_reg_write (0x00, 0x11);					// set page 0x11
	codec_reg_write (0x29, 0x01);					//headset clamp disable
	codec_reg_write (0x02, 0xA7);					//Power Down Control 2
	codec_reg_write (0x00, 0x1B);					// set page 0x1B
	codec_reg_write (0x74, 0xA7);					//Misc
	codec_reg_write (0x00, 0x11);					// set page 0x11
	codec_reg_write (0x21, 0xA6);					//set switches for Apple headset
	codec_reg_write (0x00, 0x1D);					// set page 0x1D
	codec_reg_write (0x03, 0x9F);					//ADC_VOL = Mute
	codec_reg_write (0x01, 0x00);					//ADC_DIG_BOOST; 0x00 is no boost
	codec_reg_write (0x00, 0x23);					// set page 0x23
	codec_reg_write (0x02, 0x3F);					//ADC_Vol = Mute
	codec_reg_write (0x00, 0x29);					// set page 0x29
	codec_reg_write (0x04, 0x00);					//Ch1 Bit Start UB
	codec_reg_write (0x05, 0x00);					//Ch1 Bit Start LB = 00
	codec_reg_write (0x0A, 0x00);					//Ch2 Bit Start UB
	codec_reg_write (0x0B, 0x00);					//Ch2 Bit Start LB = 00
	codec_reg_write (0x02, 0x01);					//enable ASP Transmit CH1
	codec_reg_write (0x03, 0x4A);					//RES=24 bits, CH2 and CH1
	codec_reg_write (0x01, 0x01);					//ASP_TX_EN
	codec_reg_write (0x02, 0x00);					//disable ASP Transmit CH2 and CH1
	codec_reg_write (0x02, 0x03);					//enable ASP Transmit CH2 and CH1
	HP_OUT_OFF = 0;												// reset flag

	
} // --------------------------------------------------------------------------


// codec I2C register write function (single) ---------------------------------
void codec_reg_write (uint8_t reg, uint8_t value)
{

	// issue I2C write with length equal to 1
	codec_reg_write_mult (reg, 1, &value);

} // --------------------------------------------------------------------------


// codec I2C register write function (multiple) -------------------------------
void codec_reg_write_mult (uint8_t reg, uint8_t length, uint8_t *payload)
{

	// issue I2C write if programming shunt is absent
	if (GPIO_ReadInputDataBit (GPIOD, GPIO_Pin_0)) I2C_WriteRegister (reg, length, payload);

} // --------------------------------------------------------------------------


// codec I2C register read function (single) ----------------------------------
uint8_t codec_reg_read (uint8_t reg)
{

	uint8_t temp_read;
	temp_read = 0x00;

	// fetch I2C read with length equal to 1
	codec_reg_read_mult (reg, 1, &temp_read);

	return (temp_read);

} // --------------------------------------------------------------------------


// codec I2C register read function (multiple) --------------------------------
void codec_reg_read_mult (uint8_t reg, uint8_t length, uint8_t *payload)
{

	// fetch I2C read if programming shunt is absent
	if (GPIO_ReadInputDataBit (GPIOD, GPIO_Pin_0)) I2C_ReadRegister (reg, length, payload);

} // --------------------------------------------------------------------------