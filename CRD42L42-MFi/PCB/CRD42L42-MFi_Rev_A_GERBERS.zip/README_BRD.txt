!!! BEFORE STARTING, READ THIS FILE COMPLETELY !!!

ReadMe File

Project Name:		CRD42L42-MFi 		
Circtuit Board PN:	240-01160-Z1 REV A
Date:			09/22/15
PCB Layout:		Pads Layout 9.2 or higher.
CAM System:		CAM350 v9.52 or higher.

==============================================================================

                              DATA FORMAT                            
---------------------------------------------------------------------
                               | GERBER DATA      | DRILL DATA      
===============================|==================|==================
  format                       | RS-274-X         | EXCELLON         
  Coordinate Type              | ABSOLUTE         | ABSOLUTE         
  Dimensions                   | INCHES           | INCHES           
  Zero Suppression             | LEADING          | TRAILING         
  Format Digits	               | 3(int), 5(fract) | 2(int), 4(fract) 
  Supress Repeated Coordinates | YES              | YES              
---------------------------------------------------------------------

==============================================================================

FILE NAME			DESCRIPTION/GROUP
------------------------------------------------------------------------------
ReadMe.txt			ReadMe File (this file), ASCII

--------------------------------FABRICATION-----------------------------------

240-01160-Z1_REV_A_fab_dwg.pdf	Fabrication Drawing, PDF
240-01160-Z1.ipc.net		IPC-D-356 Netlist, ASCII
240-01160-Z1.L01.gbr		Layer 01 Artwork, Primary Side
240-01160-Z1.L02.gbr		Layer 02 Artwork 
240-01160-Z1.L03.gbr		Layer 03 Artwork
240-01160-Z1.L04.gbr		Layer 04 Artwork
240-01160-Z1.L05.gbr		Layer 05 Artwork
240-01160-Z1.L06.gbr		Layer 06 Artwork
240-01160-Z1.L07.gbr		Layer 07 Artwork
240-01160-Z1.L08.gbr		Layer 08 Artwork, Secondary Side
240-01160-Z1.BRD.gbr 		Functional board outline w/o breakaways
240-01160-Z1.SMA.gbr		Solder Mask, Primary (a) Side
240-01160-Z1.SMB.gbr 		Solder Mask, Secondary (b) Side
240-01160-Z1.SSA.gbr		Silkscreen, Primary (a) Side
240-01160-Z1.SSB.gbr		Silkscreen, Secondary (b) Side
240-01160-Z1.VFA.gbr		Via Filled, Primary (a) Side
240-01160-Z1.VFB.gbr		Via Filled, Secondary (b) Side
240-01160-Z1.NC0.drl		NC Drill File, Through, ASCII
240-01160-Z1.NC0.lst		NC Drill List, Through, ASCII
240-01160-Z1.NC0.rep		N.C. Tool Report, Through, ASCII

--------------------------------ASSEMBLY---------------------------------------

603-01160-Z1_REV_A2_ASY.pdf	Assembly DWG (PRIMARY/SECONDARY) combined, PDF
505-01160-Z1.bom.xls		Assembly Bill of Materials, Excel
240-01160-Z1.XY.txt		X Y Coordinate Component Location Data, Text
240-01160-Z1.ASC		Design Layout (PADS), Text
240-01160-Z1.SPA.gbr		Solder Paste, Primary (a) Side
240-01160-Z1.SPB.gbr		Solder Paste, Secondary (b) Side

--------------------------------DFT (TEST)-------------------------------------

600-01160-Z1_REV_A2_SCH.pdf		Schematic, Searchable, PDF

--------------------------------------------------------------------------------


